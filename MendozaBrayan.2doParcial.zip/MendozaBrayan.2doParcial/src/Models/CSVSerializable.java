package Models;

@FunctionalInterface
public interface CSVSerializable {
    String toCSV();
}
